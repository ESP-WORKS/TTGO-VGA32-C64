# PlatformIO no esp64 — o que dá e o que não dá

Resumo honesto: **o `platformio.ini` sozinho não faz este projeto compilar.**

O esp64 é ESP-IDF **3.3** com o build system antigo (`make` + `component.mk`).
O `framework = espidf` atual da PlatformIO é IDF 5.x com CMake, e a documentação
é explícita: *"the list of source files is specified in the project
CMakeLists.txt file"*. Além do CMake, o código usa uma dúzia de APIs que a
Espressif removeu entre a 3.3 e a 5.x.

---

## Arquivos incluídos

| Arquivo | Para quê |
|---|---|
| `platformio.ini` | dois envs: `idf3` (legado) e `esp64` (IDF 5.5) |
| `CMakeLists.txt` (raiz) | projeto CMake |
| `main/CMakeLists.txt` | substitui `main/component.mk` |
| `components/Wire/CMakeLists.txt` | idem para o componente Wire |
| `components/Audio/CMakeLists.txt` | idem para o componente Audio |
| `sdkconfig.defaults` | traduz o `sdkconfig` original |

Os `component.mk` podem continuar onde estão — o build CMake ignora.

Detalhe do `main/CMakeLists.txt`: `main/reSID/sid.cpp` é um *unity build*, dá
`#include` em todos os `.cc` de `reSID/reSID/`. Por isso só `sid.cpp` e
`reSID.cpp` entram na lista de fontes; incluir os `.cc` daria símbolo duplicado.

---

## `[env:idf3]` — compilar como está

```ini
platform = espressif32@1.12.4
framework = espidf
src_dir = main
```

Essa é a última linha da PlatformIO que empacotava IDF 3.3, e usa o builder
SCons antigo (sem CMakeLists). Se resolver os pacotes, o código compila **sem
port nenhum**.

O risco: são pacotes de 2020. Podem não resolver mais no PlatformIO Core atual,
e o toolchain antigo pode não rodar em Apple Silicon sem Rosetta. Se der erro de
resolução de pacote, esse caminho está morto — vá para o env `esp64` ou instale
o ESP-IDF 3.3 de verdade e use o `Makefile` original (`make flash`), que é para
o que o `flashapp.sh` do projeto já aponta.

---

## `[env:esp64]` — IDF 5.5

Usa o `espressif32@6.12.0` que você já tem. Os CMakeLists resolvem o build
system, mas **o código não compila sem port**. O que precisa mudar:

### 1. `esp_event_loop.h` — removido na IDF 4.0
`main/main.c`, `main/Teensy64.h`. Basta remover o include; `esp_event.h` cobre.

### 2. Montagem do SD — `emuapi.cpp`, `emu_init()`
`sdspi_slot_config_t` / `SDSPI_SLOT_CONFIG_DEFAULT()` / `esp_vfs_fat_sdmmc_mount()`
saíram na 5.0. O caminho novo é `spi_bus_initialize()` + `sdspi_device_config_t`
+ `esp_vfs_fat_sdspi_mount()`. É a mudança mais chata, porque o barramento SPI
passa a ser inicializado explicitamente — e o `ili9341_t3dma` também usa SPI,
então atenção a qual host cada um pega (SD em HSPI, TFT em VSPI).

### 3. Áudio — `AudioPlaySystem.cpp`
Aqui mora o problema real. `I2S_MODE_DAC_BUILT_IN`, `i2s_set_dac_mode()` e
`i2s_write_bytes()` sumiram; DAC via I2S virou `driver/dac_continuous.h`, que é
uma API completamente diferente. Não é substituição linha a linha, é reescrever
o backend.

Atalho possível: o arquivo tem o caminho alternativo `#else` (timer + `dacWrite`
direto no GPIO25) que não usa I2S. Comentar `#define USE_I2S 1` no topo evita a
reescrita — mas esse caminho depende do `components/Audio`, veja o item 5.

### 4. Detalhes menores
- `portTICK_RATE_MS` → `portTICK_PERIOD_MS` (`emuapi.cpp`, `ili9341_t3dma.cpp`)
- `I2S_COMM_FORMAT_I2S_MSB` → `I2S_COMM_FORMAT_STAND_MSB`
- `adc2_get_raw` / `ADC_WIDTH_BIT_12`: o driver legado ainda existe na 5.5, mas
  só com aviso de deprecação. Compila; o `-Wno-error=deprecated-declarations`
  do `.ini` já cobre.

### 5. `components/Wire` e `components/Audio`
Esses são pedaços arrancados do core Arduino 1.0.x. Incluem `rom/ets_sys.h`
(virou `esp32/rom/ets_sys.h` na 4.x), `soc/timer_group_struct.h` com layout de
registrador antigo, e mexem direto em periférico. **É o que tem maior chance de
não compilar de jeito nenhum.**

O jeito mais rápido de sair disso: `USE_WIRE` existe só para o teclado I²C.
Comentando `#define USE_WIRE 1` no `emuapi.h`, o código cai no caminho
`driver/i2c.h` nativo, que já está escrito no arquivo — e aí `components/Wire`
some inteiro. O `components/Audio` só é necessário no caminho não-I2S do item 3.

---

## Estimativa

O env `idf3`, se os pacotes resolverem, é questão de minutos. O env `esp64` é um
dia de trabalho, e o áudio é a maior parte dele.

Se o objetivo for só ter o build no VS Code sem sair da PlatformIO, tente o
`idf3` primeiro. Se o objetivo for manter isso vivo e integrado ao seu
ecossistema de bootloader, o port para IDF 5 é o investimento certo — mas aí
vale considerar migrar o vídeo para FabGL de uma vez, já que boa parte do que
quebra (`ili9341_t3dma`, o backend de áudio) seria descartada mesmo.
